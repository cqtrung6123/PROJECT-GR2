
var MEMBER_API = "https://youtube-api-challenger2.appspot.com/members";
var btnSubmit = document.getElementById("btnSubmit");
if(btnSubmit != null){
    btnSubmit.onclick = function (){
        validateForm();
    }
}
function validateForm(){



    var passwordInput = document.forms["member"].elements["password"];
    var password = passwordInput.value;
    if (password.length == 0){
        passwordInput.nextElementSibling.innerHTML = "Invalid password!";
    }else if (password.length <6){
        passwordInput.nextElementSibling.innerHTML = "Your password longer than 6 characters!";
    }else {
        passwordInput.nextElementSibling.innerHTML = "";
    }


    var emailInput = document.forms["member"].elements["email"];
    var email = emailInput.value;
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (emailInput.value.match(validRegex)) {
        emailInput.nextElementSibling.innerHTML = "";

        document.forms.email.focus();

        return true;

    } else {
        emailInput.nextElementSibling.innerHTML = "Invalid email address!";

        document.forms.email.focus();

        return false;

    }



var object = {
        "data": {
            "type": "Member",
            "attributes": {
                "email": email,
                "password": password,
            }
        }
    }
    var xhr = new XMLHttpRequest();
    xhr.open("POST", MEMBER_API, true);
    xhr.send(JSON.stringify(object));
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 201) {
            document.getElementById("total-msg").classList = "success-msg";
            document.getElementById("total-msg").innerHTML = "Đăng kí thành công.";
        }else {
            if (xhr.readyState === XMLHttpRequest.DONE){
                var responseObject = JSON.parse(xhr.responseText);
                document.getElementById("total-msg").classList = "error-msg";
                document.getElementById("total-msg").innerHTML =
                    responseObject.errors[0].title + "" + responseObject.errors[0].detail;
            }
        }
    };


}